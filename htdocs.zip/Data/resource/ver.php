<?php
return array(
    'XYHCMS_VER'  => '3.2',
    'XYHCMS_TIME' => '20161003',
);
