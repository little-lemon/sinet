<?php
/**
 * @Author: gosea <gosea199@gmail.com>
 * @Date:   2014-06-21 10:00:00
 * @Last Modified by:   gosea
 * @Last Modified time: 2016-06-21 12:39:25
 */
namespace Home\Controller;

use Think\Controller;

//公共验证控制器HomeCommonController
class HomeCommonController extends Controller
{

    // 空操作，404页面
    public function _empty()
    {
        header("HTTP/1.1 404 Not Found");
        header("Status: 404 Not Found");
        $this->display(get_tpl('404.html'));
    }

    protected function _initialize()
    {
        if (C('CFG_WEBSITE_CLOSE') == 1) {
            exit_msg(C('CFG_WEBSITE_CLOSE_INFO'));
        }
        
       isMobile()? $_SESSION['device']='mobile':$_SESSION['device']='pc';
    }
    
    /*移动端判断*/
	

}
