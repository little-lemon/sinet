<?php
	
namespace Home\Controller;

use Common\Lib\Category;

/**
 * 栏目控制器
 */
class TestController extends HomeCommonController
{
	public function test()
	{
		
		echo $_SESSION['device'];
		//echo 45;
		//echo $data;
	}
}

?>