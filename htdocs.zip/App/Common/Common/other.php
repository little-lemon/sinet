<?php
/***
 *用户自定义函数文件，二次开发，可将函数写于此，升级不会覆盖此文件
 ***/

//XXXtest为测试数据
function xxxtest()
{
    echo "xxxtest function";
}

// 删除图片：参数：一维数组：所有要删除的图片的路径
function deleteImage($images)
{
    foreach ($images as $v) {
        @unlink($v);
    }
}

/**
 * 传入时间 秒,计算剩余的时间
 * @param  number $time 时间
 * @return string n年n月n天n小时n分钟n秒
 */
function left_time($time) {
	if($time > 0){
		$f = array(
			'31536000'=> '年',
			'2592000' => '个月',
			'604800'  => '周',
			'86400'   => '天',
			'3600'    => '小时',
			'60'      => '分钟',
			'1'       => '秒'
		);
		$stime = '';
		foreach($f as $k=>$v){
			if(0 != $c=floor($time/(int)$k)){
				$stime .= $c.$v;
				$time = $time % $k;
			}
		}
		return $stime;
	}else{
		return '';
	}
}

    //判断是访问的pc端设备还是手机端设备
	function judgeDevice()
	{ 
	    // 如果有HTTP_X_WAP_PROFILE则一定是移动设备
	    if (isset ($_SERVER['HTTP_X_WAP_PROFILE']))
	    {
	    	$_SESSION['device']= 'mobile';
	        //return true;
	    }elseif(isset ($_SERVER['HTTP_VIA'])){
	    	$_SESSION['device']= 'mobile';
	    }elseif(isset ($_SERVER['HTTP_USER_AGENT'])){
	    	$clientkeywords = array ('nokia','sony','ericsson','mot','samsung','htc','sgh','lg','sharp','sie-','philips',
	            'panasonic','alcatel','lenovo','iphone',
	            'ipod','blackberry',
	            'meizu','android','netfront',
	            'symbian','ucweb',
	            'windowsce','palm','operamini','operamobi','openwave','nexusone','cldc','midp','wap','mobile'
	        ); 
	        if (preg_match("/(" . implode('|', $clientkeywords) . ")/i", strtolower($_SERVER['HTTP_USER_AGENT'])))
	        {
	            $_SESSION['device'] = 'mobile';
	        } else{
	        	$_SESSION['device'] = 'pc';
	        }
	    }elseif(isset ($_SERVER['HTTP_VIA'])){
	    	if(stristr($_SERVER['HTTP_VIA'], "wap")){
	    		$_SESSION['device']= 'mobile';
	    	}else{
	    		$_SESSION['device'] = 'pc';
	    	}
	    }elseif(isset ($_SERVER['HTTP_ACCEPT'])){
	        // 如果只支持wml并且不支持html那一定是移动设备
	        // 如果支持wml和html但是wml在html之前则是移动设备
	        if ((strpos($_SERVER['HTTP_ACCEPT'], 'vnd.wap.wml') !== false) && (strpos($_SERVER['HTTP_ACCEPT'], 'text/html') === false || (strpos($_SERVER['HTTP_ACCEPT'], 'vnd.wap.wml') < strpos($_SERVER['HTTP_ACCEPT'], 'text/html'))))
	        {
	            $_SESSION['device'] = 'mobile';
	        } 
	    } else{
	    	$_SESSION['device'] = 'pc';
	    }
	} 
	
	
	
	/*移动端判断*/
	function isMobile()
	{ 
	    // 如果有HTTP_X_WAP_PROFILE则一定是移动设备
	    if (isset ($_SERVER['HTTP_X_WAP_PROFILE']))
	    {
	        return true;
	    } 
	    // 如果via信息含有wap则一定是移动设备,部分服务商会屏蔽该信息
	    if (isset ($_SERVER['HTTP_VIA']))
	    { 
	        // 找不到为flase,否则为true
	        return stristr($_SERVER['HTTP_VIA'], "wap") ? true : false;
	    } 
	    // 脑残法，判断手机发送的客户端标志,兼容性有待提高
	    if (isset ($_SERVER['HTTP_USER_AGENT']))
	    {
	        $clientkeywords = array ('nokia',
	            'sony',
	            'ericsson',
	            'mot',
	            'samsung',
	            'htc',
	            'sgh',
	            'lg',
	            'sharp',
	            'sie-',
	            'philips',
	            'panasonic',
	            'alcatel',
	            'lenovo',
	            'iphone',
	            'ipod',
	            'blackberry',
	            'meizu',
	            'android',
	            'netfront',
	            'symbian',
	            'ucweb',
	            'windowsce',
	            'palm',
	            'operamini',
	            'operamobi',
	            'openwave',
	            'nexusone',
	            'cldc',
	            'midp',
	            'wap',
	            'mobile'
	            ); 
	        // 从HTTP_USER_AGENT中查找手机浏览器的关键字
	        if (preg_match("/(" . implode('|', $clientkeywords) . ")/i", strtolower($_SERVER['HTTP_USER_AGENT'])))
	        {
	            return true;
	        } 
	    } 
	    // 协议法，因为有可能不准确，放到最后判断
	    if (isset ($_SERVER['HTTP_ACCEPT']))
	    { 
	        // 如果只支持wml并且不支持html那一定是移动设备
	        // 如果支持wml和html但是wml在html之前则是移动设备
	        if ((strpos($_SERVER['HTTP_ACCEPT'], 'vnd.wap.wml') !== false) && (strpos($_SERVER['HTTP_ACCEPT'], 'text/html') === false || (strpos($_SERVER['HTTP_ACCEPT'], 'vnd.wap.wml') < strpos($_SERVER['HTTP_ACCEPT'], 'text/html'))))
	        {
	            return true;
	        } 
	    } 
	    return false;
	} 

?>