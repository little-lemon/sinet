<?php return array (
  'DB_TYPE' => 'mysqli',
  'DB_HOST' => '127.0.0.1',
  'DB_PORT' => '3306',
  'DB_USER' => 'root',
  'DB_PWD' => 'root',
  'DB_NAME' => 'haixia',
  'DB_PREFIX' => 'si_',
  'DB_CHARSET' => 'utf8',
);?>