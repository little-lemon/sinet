<?php
/**
 * @Author: gosea <gosea199@gmail.com>
 * @Date:   2014-06-21 10:00:00
 * @Last Modified by:   gosea
 * @Last Modified time: 2016-06-21 12:31:56
 */

namespace Manage\Controller;

use Think\Controller;
/**
 * 广告位相关
 */
class CustomController extends CommonController
{

    public function index()
    {

        $this->display();
    }


}
