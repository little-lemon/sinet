<?php
/**
 * 内容权限管理
 */
namespace Manage\Controller;
class ContentPermissionController extends CommonContentController
{

    public function index()
    {		
		$roleData = M('role')->field('name,id')->select();
		$cateData = M('category')->where('pid = 0')->field('name,id')->select();
		$sql = "select b.catid,b.roleid from si_category as a join si_category_access b on a.pid = 0 and a.id = b.catid";
		$data = M()->query($sql);
		$accessStr = ',';
		foreach($data as $k => $v){
			$str = '';
			$str = join("_",$v);
			$accessStr .= $str.',';
		}
		$this->assign(array(
			'roleData'   => $roleData,
			'cateData'  => $cateData,
			'accessStr' => $accessStr
		));
        $this->display();
    }
	
	 public function indexPost()
	 {
		 if(IS_POST){
			$data = I('post.');
			if(!empty($data)){
				$cateAccessData = array();
				$index = 0;
				foreach($data as $key => $value){
					$tmp = explode('_',$key);
					$len = count($value);
					for($i = 0; $i < $len; $i++){
						$cateAccessData[$index]['catid']  = $value[$i];
						$cateAccessData[$index]['roleid'] = $tmp[1];
						$cateAccessData[$index]['flag'] = 1;
						$cateAccessData[$index]['action'] = 'index';	
						$index ++;	
						$childData = M('category')->where("pid = $value[$i]")->select();
						foreach($childData as $k2 => $v2){
							$cateAccessData[$index]['catid']  =$v2['id'];
							$cateAccessData[$index]['roleid'] = $tmp[1];
							$cateAccessData[$index]['flag'] = 1;
							$cateAccessData[$index]['action'] = 'index';
							$index ++;	
							$cateAccessData[$index]['catid']  =$v2['id'];
							$cateAccessData[$index]['roleid'] = $tmp[1];
							$cateAccessData[$index]['flag'] = 1;
							$cateAccessData[$index]['action'] = 'add';
							$index ++;	
							$cateAccessData[$index]['catid']  =$v2['id'];
							$cateAccessData[$index]['roleid'] = $tmp[1];
							$cateAccessData[$index]['flag'] = 1;
							$cateAccessData[$index]['action'] = 'edit';
							$index ++;	
							$cateAccessData[$index]['catid']  =$v2['id'];
							$cateAccessData[$index]['roleid'] = $tmp[1];
							$cateAccessData[$index]['flag'] = 1;
							$cateAccessData[$index]['action'] = 'del';
							$index ++;	
							$cateAccessData[$index]['catid']  =$v2['id'];
							$cateAccessData[$index]['roleid'] = $tmp[1];
							$cateAccessData[$index]['flag'] = 1;
							$cateAccessData[$index]['action'] = 'move';
							$index ++;	
						}					
					}
				}
				$sql = 'truncate table si_category_access';
				M()->execute($sql);
				M('categoryAccess')->addAll($cateAccessData);
				$this->success('修改成功', U('ContentPermission/index'));
			}
		}
	 }

}
